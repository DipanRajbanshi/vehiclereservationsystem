<?php
session_start();
include('vendor/inc/config.php');
include('vendor/inc/checklogin.php');
check_login();
$aid = $_SESSION['u_id'];

if (isset($_POST['book_vehicle'])) {
    $u_id = $_SESSION['u_id'];
    $u_car_type = $_POST['u_car_type'];
    $u_car_regno = $_POST['u_car_regno'];
    $u_car_bookdate = $_POST['u_car_bookdate'];
    $u_car_returndate = $_POST['u_car_returndate'];
    $u_car_book_status = $_POST['u_car_book_status'];
    $price_per_day = $_POST['price_per_day'];
    $total_cost = $_POST['total_cost'];

    $query = "UPDATE tms_user SET u_car_type=?, u_car_bookdate=?, u_car_returndate=?, u_car_regno=?, u_car_book_status=?, price_per_day=?, total_cost=? WHERE u_id=?";
    $stmt = $mysqli->prepare($query);
    
    if ($stmt) {
        $rc = $stmt->bind_param('ssssssdi', $u_car_type, $u_car_bookdate, $u_car_returndate, $u_car_regno, $u_car_book_status, $price_per_day, $total_cost, $u_id);
        $stmt->execute();
        
        if ($stmt->affected_rows > 0) {
            $succ = "Booking Submitted";
        } else {
            $err = "Please Try Again Later";
        }
    } else {
        $err = "Failed to prepare statement: " . mysqli_error($mysqli);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<?php include('vendor/inc/head.php'); ?>
<body id="page-top">
  <?php include("vendor/inc/nav.php"); ?>

  <div id="wrapper">
    <?php include("vendor/inc/sidebar.php"); ?>
    <div id="content-wrapper">
      <div class="container-fluid">
        <?php if (isset($succ)) { ?>
          <script>
            setTimeout(function () {
              swal("Success!", "<?php echo $succ; ?>!", "success");
            }, 100);
          </script>
        <?php } ?>
        <?php if (isset($err)) { ?>
          <script>
            setTimeout(function () {
              swal("Failed!", "<?php echo $err; ?>!", "error");
            }, 100);
          </script>
        <?php } ?>

        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="user-dashboard.php">Dashboard</a>
          </li>
          <li class="breadcrumb-item">Vehicle</li>
          <li class="breadcrumb-item">Book Vehicle</li>
          <li class="breadcrumb-item active">Confirm Booking</li>
        </ol>
        <hr>
        <div class="card">
          <div class="card-header">Confirm Booking</div>
          <div class="card-body">
            <?php
            $aid = $_GET['v_id'];
            $ret = "SELECT * FROM tms_vehicle WHERE v_id=?";
            $stmt = $mysqli->prepare($ret);
            $stmt->bind_param('i', $aid);
            $stmt->execute(); // ok
            $res = $stmt->get_result();
            while ($row = $res->fetch_object()) {
            ?>
              <form method="POST">
                <div class="form-group">
                  <label for="exampleInputEmail1">Vehicle Category</label>
                  <input type="text" value="<?php echo $row->v_category; ?>" readonly class="form-control" name="u_car_type">
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Vehicle Registration Number</label>
                  <input type="email" value="<?php echo $row->v_reg_no; ?>" readonly class="form-control" name="u_car_regno">
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Booking Date</label>
                  <input type="date" class="form-control" id="bookingDate" name="u_car_bookdate" required>
                </div>
                <div class="form-group">
                  <label for="u_car_returndate">Return Date</label>
                  <input type="date" class="form-control" id="returnDate" name="u_car_returndate" required>
                </div>
                <div class="form-group">
                  <label for="pricePerDay">Price Per Day</label>
                  <input type="number" class="form-control" id="pricePerDay" name="price_per_day" required>
                </div>
                <div class="form-group">
                  <label for="totalCost">Total Cost</label>
                  <input type="text" class="form-control" id="totalCost" name="total_cost" readonly>
                </div>
                <div class="form-group" style="display:none">
                  <label for="exampleInputEmail1">Book Status</label>
                  <input type="text" value="Pending" class="form-control" id="exampleInputEmail1" name="u_car_book_status">
                </div>
                <button type="submit" name="book_vehicle" class="btn btn-success">Confirm Booking</button>
              </form>
            <?php } ?>
          </div>
        </div>
        <hr>
        <?php include("vendor/inc/footer.php"); ?>
      </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-danger" href="admin-logout.php">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <script src="vendor/js/sb-admin.min.js"></script>
    <script src="vendor/js/demo/datatables-demo.js"></script>
    <script src="vendor/js/demo/chart-area-demo.js"></script>
   
    <script src="vendor/js/swal.js"></script>
    
    <script>
    document.addEventListener('DOMContentLoaded', (event) => {
        function calculateTotalCost() {
            const bookingDate = new Date(document.getElementById('bookingDate').value);
            const returnDate = new Date(document.getElementById('returnDate').value);
            const pricePerDay = parseFloat(document.getElementById('pricePerDay').value);
            
            if (bookingDate && returnDate && pricePerDay && returnDate >= bookingDate) {
                const timeDifference = returnDate.getTime() - bookingDate.getTime();
                const daysDifference = timeDifference / (1000 * 3600 * 24) + 1; 
                const totalCost = daysDifference * pricePerDay;
                
                document.getElementById('totalCost').value = totalCost.toFixed(2);
            } else {
                document.getElementById('totalCost').value = '';
            }
        }

        document.getElementById('bookingDate').addEventListener('change', calculateTotalCost);
        document.getElementById('returnDate').addEventListener('change', calculateTotalCost);
        document.getElementById('pricePerDay').addEventListener('input', calculateTotalCost);
    });
    </script>
</body>
</html>
